create trigger t_afterdelete_on_mystocks
  after DELETE
  on User
  for each row
  begin   
      delete from MyStocks where UserID=old.ID;        
end;

